#include <windows.h>
#include <vector>
#include <cstdlib>
#include <ctime>

int main() {
    // 1. Hi?n th�ng b�o h?i ? ki?n
    int msgboxID = MessageBox(NULL, "Running? You can turn it off by pressing the Esc key.", "Uranium.exe", MB_YESNO | MB_ICONQUESTION);
    if (msgboxID != IDYES) return 0;

    srand(time(0));
    HDC hdc = GetDC(NULL); // L?y DC �? v? l�n m�n h?nh
    int dx = 10, dy = 10;
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    POINT p;

    // 2. V?ng l?p cho c? chu?t v� v?
    while (!(GetAsyncKeyState(VK_ESCAPE) & 0x8000)) {
        GetCursorPos(&p);

        // B?t c?nh
        if (p.x + dx >= screenWidth || p.x + dx <= 0) dx = -dx;
        if (p.y + dy >= screenHeight || p.y + dy <= 0) dy = -dy;
        SetCursorPos(p.x + dx, p.y + dy);

        // 3. V? line m�u v�ng ng?u nhi�n theo v? tr� chu?t
        HPEN hPen = CreatePen(PS_SOLID, 2, RGB(255, 255, 0));
        SelectObject(hdc, hPen);
        MoveToEx(hdc, p.x, p.y, NULL);
        LineTo(hdc, rand() % screenWidth, rand() % screenHeight);
        DeleteObject(hPen);

        Sleep(20);
    }

    // D?n d?p tr�?c khi tho�t
    ReleaseDC(NULL, hdc);
    InvalidateRect(NULL, NULL, TRUE); // L�m s?ch m�n h?nh khi tho�t
    return 0; {


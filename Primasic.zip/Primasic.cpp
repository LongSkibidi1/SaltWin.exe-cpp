#include <windows.h>

#pragma comment(lib, "user32.lib")

int main() {

    MessageBoxA(
        NULL,
        "Press ESC to stop",
        "Error Cursor",
        MB_OK | MB_ICONINFORMATION
    );

    // Load red X error icon
    HICON hError = LoadIcon(
        NULL,
        IDI_ERROR
    );

    int dx = 15;
    int dy = 15;

    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    HDC hdc = GetDC(NULL);

    while (!(GetAsyncKeyState(VK_ESCAPE) & 0x8000)) {

        POINT p;
        GetCursorPos(&p);

        // Bounce cursor
        if (p.x + dx >= sw || p.x + dx <= 0)
            dx = -dx;

        if (p.y + dy >= sh || p.y + dy <= 0)
            dy = -dy;

        // Move cursor
        SetCursorPos(
            p.x + dx,
            p.y + dy
        );

        // Draw red X icon
        DrawIcon(
            hdc,
            p.x - 16,
            p.y - 16,
            hError
        );

        Sleep(10);
    }

    ReleaseDC(NULL, hdc);

    return 0;
}
